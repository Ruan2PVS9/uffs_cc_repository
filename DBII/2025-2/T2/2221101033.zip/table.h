#ifndef TABLE_H
#define TABLE_H

#include "structures.h"

int findTable(char *table_name, Table *table);

#endif
