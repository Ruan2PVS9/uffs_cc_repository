#ifndef ATTRIBUTE_H
#define ATTRIBUTE_H

#include "structures.h"

int findAttributes(int table_id, Attribute *attributes);

#endif
